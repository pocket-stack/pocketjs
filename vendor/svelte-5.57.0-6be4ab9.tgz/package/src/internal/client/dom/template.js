/** @import { Effect, EffectNodes, TemplateNode } from '#client' */
/** @import { TemplateStructure } from './types' */
import {
	COMMENT_NODE,
	DOCUMENT_FRAGMENT_NODE,
	IS_XHTML,
	REACTION_RAN,
	TEXT_NODE
} from '#client/constants';
import {
	NAMESPACE_MATHML,
	NAMESPACE_SVG,
	TEMPLATE_FRAGMENT,
	TEMPLATE_USE_IMPORT_NODE,
	TEMPLATE_USE_MATHML,
	TEMPLATE_USE_SVG
} from '../../../constants.js';
import { current_renderer, parent_renderer } from '../custom-renderer/state.js';
import { custom_renderers_flag } from '../../flags/index.js';
import { active_effect } from '../runtime.js';
import { hydrate_next, hydrate_node, hydrating, set_hydrate_node } from './hydration.js';
import {
	append_child,
	clone_node,
	create_comment,
	create_element,
	create_fragment,
	create_text,
	get_first_child,
	get_last_child,
	get_node_value,
	import_node,
	insert_before,
	is_firefox,
	merge_text_nodes,
	node_name,
	node_type,
	replace_with,
	set_attribute,
	set_text_content
} from './operations.js';
import { create_fragment_from_html } from './reconciler.js';

const TEMPLATE_TAG = IS_XHTML ? 'template' : 'TEMPLATE';
const SCRIPT_TAG = IS_XHTML ? 'script' : 'SCRIPT';

/**
 * @param {TemplateNode} start
 * @param {TemplateNode | null} end
 */
export function assign_nodes(start, end) {
	var effect = /** @type {Effect} */ (active_effect);
	if (effect.nodes === null) {
		effect.nodes = {
			start,
			end,
			segments: should_segment_nodes(effect)
				? [{ start, end, r: current_renderer, pr: parent_renderer }]
				: null,
			a: null,
			t: null
		};
	} else if (should_segment_nodes(effect)) {
		var nodes = effect.nodes;
		(nodes.segments ??= [{ start: nodes.start, end: nodes.end, r: effect.r, pr: effect.pr }]).push({
			start,
			end,
			r: current_renderer,
			pr: parent_renderer
		});
	}
}

/**
 * @param {Effect} effect
 */
function should_segment_nodes(effect) {
	return (
		custom_renderers_flag &&
		(current_renderer !== effect.r || parent_renderer !== effect.pr) &&
		(current_renderer?.foreign != null || parent_renderer?.foreign != null)
	);
}

/**
 * @param {string} content
 * @param {number} flags
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
export function from_html(content, flags) {
	var is_fragment = (flags & TEMPLATE_FRAGMENT) !== 0;
	var use_import_node = (flags & TEMPLATE_USE_IMPORT_NODE) !== 0;

	/** @type {Node} */
	var node;

	/**
	 * Whether or not the first item is a text/element node. If not, we need to
	 * create an additional comment node to act as `effect.nodes.start`
	 */
	var has_start = !content.startsWith('<!>');

	return () => {
		if (hydrating) {
			assign_nodes(hydrate_node, null);
			return hydrate_node;
		}

		if (node === undefined) {
			node = create_fragment_from_html(has_start ? content : '<!>' + content);
			if (!is_fragment) node = /** @type {TemplateNode} */ (get_first_child(node));
		}

		var clone = /** @type {TemplateNode} */ (
			use_import_node || is_firefox ? import_node(node, true) : clone_node(node, true)
		);

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ (get_first_child(clone));
			var end = /** @type {TemplateNode} */ (get_last_child(clone));

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {string} content
 * @param {number} flags
 * @param {'svg' | 'math'} ns
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
function from_namespace(content, flags, ns = 'svg') {
	/**
	 * Whether or not the first item is a text/element node. If not, we need to
	 * create an additional comment node to act as `effect.nodes.start`
	 */
	var has_start = !content.startsWith('<!>');

	var is_fragment = (flags & TEMPLATE_FRAGMENT) !== 0;
	var wrapped = `<${ns}>${has_start ? content : '<!>' + content}</${ns}>`;

	/** @type {Element | DocumentFragment} */
	var node;

	return () => {
		if (hydrating) {
			assign_nodes(hydrate_node, null);
			return hydrate_node;
		}

		if (!node) {
			var fragment = /** @type {DocumentFragment} */ (create_fragment_from_html(wrapped));
			var root = /** @type {Element} */ (get_first_child(fragment));

			if (is_fragment) {
				node = create_fragment();
				while (get_first_child(root)) {
					append_child(node, /** @type {TemplateNode} */ (get_first_child(root)));
				}
			} else {
				node = /** @type {Element} */ (get_first_child(root));
			}
		}

		var clone = /** @type {TemplateNode} */ (clone_node(node, true));

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ (get_first_child(clone));
			var end = /** @type {TemplateNode} */ (get_last_child(clone));

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {string} content
 * @param {number} flags
 */
/*#__NO_SIDE_EFFECTS__*/
export function from_svg(content, flags) {
	return from_namespace(content, flags, 'svg');
}

/**
 * @param {string} content
 * @param {number} flags
 */
/*#__NO_SIDE_EFFECTS__*/
export function from_mathml(content, flags) {
	return from_namespace(content, flags, 'math');
}

/**
 * @param {TemplateStructure[]} structure
 * @param {typeof NAMESPACE_SVG | typeof NAMESPACE_MATHML | undefined} [ns]
 */
function fragment_from_tree(structure, ns) {
	var fragment = create_fragment();

	for (var item of structure) {
		if (typeof item === 'string') {
			append_child(fragment, create_text(item));
			continue;
		}

		// if `preserveComments === true`, comments are represented as `['// <data>']`
		if (item === undefined || item[0][0] === '/') {
			append_child(fragment, create_comment(item ? item[0].slice(3) : ''));
			continue;
		}

		const [name, attributes, ...children] = item;

		const namespace = name === 'svg' ? NAMESPACE_SVG : name === 'math' ? NAMESPACE_MATHML : ns;

		var element = create_element(name, namespace, attributes?.is);

		for (var key in attributes) {
			set_attribute(element, key, attributes[key]);
		}

		if (children.length > 0) {
			var target =
				node_name(element) === TEMPLATE_TAG
					? // this is safe for custom renderers because the name will never be `template` due to how `node_name` works
						/** @type {HTMLTemplateElement} */ (element).content
					: element;

			append_child(
				target,
				fragment_from_tree(children, node_name(element) === 'foreignObject' ? undefined : namespace)
			);
		}

		append_child(fragment, element);
	}

	return fragment;
}

/**
 * @param {TemplateStructure[]} structure
 * @param {number} flags
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
export function from_tree(structure, flags) {
	var is_fragment = (flags & TEMPLATE_FRAGMENT) !== 0;
	var use_import_node = (flags & TEMPLATE_USE_IMPORT_NODE) !== 0;

	/** @type {Node} */
	var node;

	return () => {
		if (hydrating) {
			assign_nodes(hydrate_node, null);
			return hydrate_node;
		}

		// for the custom renderer we skip the cloning and create new nodes every time...a bit less efficient
		// but save custom renderers implementors from having to implement importNode or cloneNode
		// which can be a pain
		if (node === undefined || current_renderer != null) {
			const ns =
				(flags & TEMPLATE_USE_SVG) !== 0
					? NAMESPACE_SVG
					: (flags & TEMPLATE_USE_MATHML) !== 0
						? NAMESPACE_MATHML
						: undefined;

			node = fragment_from_tree(structure, ns);
			if (!is_fragment) node = /** @type {TemplateNode} */ (get_first_child(node));
		}

		var clone = /** @type {TemplateNode} */ (
			current_renderer != null
				? node
				: use_import_node || is_firefox
					? import_node(node, true)
					: clone_node(node, true)
		);

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ (get_first_child(clone));
			var end = /** @type {TemplateNode} */ (get_last_child(clone));

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {() => Element | DocumentFragment} fn
 */
export function with_script(fn) {
	return () => run_scripts(fn());
}

/**
 * Creating a document fragment from HTML that contains script tags will not execute
 * the scripts. We need to replace the script tags with new ones so that they are executed.
 * @param {Element | DocumentFragment} node
 * @returns {Node | Node[]}
 */
function run_scripts(node) {
	// this should be custom renderer safe since we never emit `with_script` in that case
	// scripts were SSR'd, in which case they will run
	if (hydrating) return node;

	const is_fragment = node_type(node) === DOCUMENT_FRAGMENT_NODE;
	const scripts =
		node_name(node) === SCRIPT_TAG
			? [/** @type {HTMLScriptElement} */ (node)]
			: node.querySelectorAll('script');

	const effect = /** @type {Effect & { nodes: EffectNodes }} */ (active_effect);

	for (const script of scripts) {
		const clone = create_element('script');

		for (var attribute of script.attributes) {
			set_attribute(clone, attribute.name, attribute.value);
		}

		set_text_content(clone, script.textContent ?? '');

		// The script has changed - if it's at the edges, the effect now points at dead nodes
		if (is_fragment ? get_first_child(node) === script : node === script) {
			effect.nodes.start = clone;
		}
		if (is_fragment ? get_last_child(node) === script : node === script) {
			effect.nodes.end = clone;
		}

		replace_with(script, clone);
	}
	return node;
}

/**
 * Don't mark this as side-effect-free, hydration needs to walk all nodes
 * @param {any} value
 */
export function text(value = '') {
	if (!hydrating) {
		var t = create_text(value + '');
		assign_nodes(t, t);
		return t;
	}

	var node = hydrate_node;

	if (node_type(node) !== TEXT_NODE) {
		// if an {expression} is empty during SSR, we need to insert an empty text node
		insert_before(node, (node = create_text()));
		set_hydrate_node(node);
	} else {
		merge_text_nodes(/** @type {Text} */ (node));
	}

	assign_nodes(node, node);
	return node;
}

/**
 * @returns {TemplateNode | DocumentFragment}
 */
export function comment() {
	// we're not delegating to `template` here for performance reasons
	if (hydrating) {
		assign_nodes(hydrate_node, null);
		return hydrate_node;
	}

	var frag = create_fragment();
	var start = create_comment('');
	var anchor = create_text();
	append_child(frag, start);
	append_child(frag, anchor);

	assign_nodes(start, anchor);

	return frag;
}

/**
 * Assign the created (or in hydration mode, traversed) dom elements to the current block
 * and insert the elements into the dom (in client mode).
 * @param {Text | Comment | Element} anchor
 * @param {DocumentFragment | Element} dom
 */
export function append(anchor, dom) {
	if (hydrating) {
		var effect = /** @type {Effect & { nodes: EffectNodes }} */ (active_effect);

		// When hydrating and outer component and an inner component is async, i.e. blocked on a promise,
		// then by the time the inner resolves we have already advanced to the end of the hydrated nodes
		// of the parent component. Check for defined for that reason to avoid rewinding the parent's end marker.
		if ((effect.f & REACTION_RAN) === 0 || effect.nodes.end === null) {
			effect.nodes.end = hydrate_node;

			// this is to cover interleaved custom renders where an hydrated dom component interleaves with a custom renderer
			// since it will use segments instead of start/end, we need to make sure to update the segment's end as well
			if (effect.nodes.segments !== null) {
				effect.nodes.segments[0].end = hydrate_node;
			}
		}

		hydrate_next();
		return;
	}

	if (anchor === null) {
		// edge case — void `<svelte:element>` with content
		return;
	}

	insert_before(anchor, /** @type {Node} */ (dom));
}

/**
 * Create (or hydrate) an unique UID for the component instance.
 */
export function props_id() {
	let node_value;
	if (
		hydrating &&
		hydrate_node &&
		node_type(hydrate_node) === COMMENT_NODE &&
		(node_value = get_node_value(hydrate_node))?.startsWith(`$`)
	) {
		const id = node_value.substring(1);
		hydrate_next();
		return id;
	}
	// @ts-expect-error This way we ensure the id is unique even across Svelte runtimes
	(globalThis.__svelte ??= {}).uid ??= 1;

	// @ts-expect-error
	return `c${globalThis.__svelte.uid++}`;
}
