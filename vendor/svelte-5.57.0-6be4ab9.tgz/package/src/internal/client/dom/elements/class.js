import { to_class } from '../../../shared/attributes.js';
import { CLASS_CACHE } from '../../constants.js';
import { hydrating } from '../hydration.js';
import {
	class_list_toggle,
	get_attribute,
	remove_attribute,
	set_attribute
} from '../operations.js';

/**
 * @param {Element} dom
 * @param {boolean | number} is_html
 * @param {string | null} value
 * @param {string} [hash]
 * @param {Record<string, any>} [prev_classes]
 * @param {Record<string, any>} [next_classes]
 * @returns {Record<string, boolean> | undefined}
 */
export function set_class(dom, is_html, value, hash, prev_classes, next_classes) {
	var prev = /** @type {any} */ (dom)[CLASS_CACHE];

	if (
		hydrating ||
		prev !== value ||
		prev === undefined // for edge case of `class={undefined}`
	) {
		var next_class_name = to_class(value, hash, next_classes);

		if (!hydrating || next_class_name !== get_attribute(dom, 'class')) {
			// Removing the attribute when the value is only an empty string causes
			// performance issues vs simply making the className an empty string. So
			// we should only remove the class if the value is nullish
			// and there no hash/directives :
			if (next_class_name == null) {
				remove_attribute(dom, 'class');
			} else if (is_html) {
				dom.className = next_class_name;
			} else {
				set_attribute(dom, 'class', next_class_name);
			}
		}

		/** @type {any} */ (dom)[CLASS_CACHE] = value;
	} else if (next_classes && prev_classes !== next_classes) {
		for (var key in next_classes) {
			var is_present = !!next_classes[key];

			if (prev_classes == null || is_present !== !!prev_classes[key]) {
				class_list_toggle(/** @type {HTMLElement} */ (dom), key, is_present);
			}
		}
	}

	return next_classes;
}
